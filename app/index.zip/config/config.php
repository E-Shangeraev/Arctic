<?php

$config = array(
    'db' => array(
        'server' => 'localhost',
        'username' => 'mysql',
        'password' => 'mysql',
        'name' => 'arctic_db'
    )
    // 'db' => array(
    //     'server' => 'localhost',
    //     'username' => 'u0965960_default',
    //     'password' => 'E6h_!1_n',
    //     'name' => 'u0965960_default'
    // )
);

require 'db.php';
// require 'functions.php';